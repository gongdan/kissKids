var imglist = {};
var pagedata = {};
var cacheImg = {}
var elementsData = {};
var albumstemp;
var pageparm = {
    pagelist: [],
    pageloaded: [],
    myCanvas: {},
    imgPage: {},
    imgBox:{},
    pushPage:function(pn){
        var pageLen = this.pagelist.length;
        if(parm.printtype==3&&pageLen>0)
        {
            var coverType = pagedata[this.pagelist[pageLen-1]].coverType||'-1'
            if(coverType==2){
                this.pagelist.splice(pageLen-1,0,pn);
            }
            else
                this.pagelist.push(pn);
        }
        else{
            this.pagelist.push(pn);
        }
    }
};
var viewParm = {
    scaleW: function () {
        return  widthOrg/720;
    },
    scaleH: function () {
        return  heightOrg/1156;
    },
    left: function () {
        return parseInt(80 * this.scaleW());
    },
    right: function () {
        return parseInt(80 * this.scaleW());
    },
    top: function () {
        var v;
        if (parm.printtype == 1)
            v = 105;
        else if (parm.printtype == 2)
            v = 175;
        else
            v = 70;
        return parseInt(v * this.scaleH());
    },
    bottom: function () {
        var v;
        if (parm.printtype == 1)
            v = 224;
        else if (parm.printtype == 2)
            v = 294;
        else
            v = 184;
        return parseInt(v * this.scaleH());
    },
    lrbtnT: function () {
        return parseInt(370 * this.scaleH());
    },
    lrbtnW: function () {
        return parseInt(80 * this.scaleW());
    },
    editBtnH: function () {
        var v;
        if (parm.printtype == 0)
            v = 115;
        else
            v = 100;
        return parseInt(v * this.scaleH());
    },
    paginationT: function () {
        return -parseInt(30 * this.scaleH());
    },
    paginationFS: function () {
        return parseInt(22 * this.scaleW());
    },
    toprintW: function () {
        return parseInt(530 * this.scaleW());
    },
    toprintH: function () {
        return parseInt(70 * this.scaleH());
    },
    toprintT: function () {
        return parseInt(15 * this.scaleH());
    },
    toprintFS: function () {
        return parseInt(26 * this.scaleW());
    },
    pagedelW: function () {
        return parseInt(40 * this.scaleW()/parm.zoomScale);
    },
    pagedelR: function () {
        var translate = parm.printtype==3?(getScaleValue((jsonOrg.height-jsonOrg.width)/2)):0;
        return parseInt(20 * this.scaleW()/parm.zoomScale+translate);
    },
    editBtnImgW: function () {
        return parseInt(56 * this.scaleW());
    },
    editBtnFS: function () {
        return parseInt(22 * this.scaleW());
    },
    editBtnFLH: function () {
        return parseInt(32 * this.scaleW());
    }
}
var pageScale = {
    value: 1,
    set: function (v) {
        this.value = v;
    },
    Multiply: function (v) {
        return parseInt(v * this.value);
    },
    Divide: function (v) {
        return parseInt(v / this.value);
    }
}
var parm = {
    pageno: 0,
    currentpage: 1,
    newno: 2000,
    ratio: 1.6,
    scalebyh: true,
    printtype: 0,
    zoomScale:false,
    newAlbums:false,
    customAlbums:'',
    tip:false,
    isSupportAlbumPrint:0
};
(function () {
    var img = new Image();
    img.src = 'http://osscdn2.banketime.com/apk/_272114491368569704.png';
    img.onload = function () {
        cacheImg.addImgTagIcon = this;
    };
    var errImg = new Image();
    errImg.src = 'http://osscdn2.banketime.com/apk/_692214537130298288.png';
    errImg.onload = function () {
        cacheImg.errImgTagIcon = this;
    };
})();
function dataInit(d) {
    var data;
    if (typeof(d) == 'object')
        data = d;
    else
        data = JSON.parse(d);
    jsonOrg = data;
    parm.newno = data.maxno ? data.maxno : parm.newno;
    parm.scalebyh = heightOrg / widthOrg >= 1.6 ? true : false;
    pageScale.set(parm.scalebyh ? widthOrg / data.width : heightOrg / data.height);
    var pages = $('#pages');
    pages.css({'width': getScaleValue(data.width) + 'px', 'height': getScaleValue(data.height) + 'px'});
    if (parm.scalebyh)
        pages.css({'top': (heightOrg - getScaleValue(data.height)) / 2 + 'px'});
    else
        pages.css({'left': (widthOrg - getScaleValue(data.width)) / 2 + 'px'})
    mediasData = data.medias;
    if(parm.printtype==3)
    {
        var coverAlbums = JSON.parse('{"width":720,"height":1156,"id":"1","title":"影集照片书封面","pages":[{"no":1,"coverType":"1","delable":"2","elements":[{"no":2,"type":"0","position":"absolute","background_color":"#fff8d1"},{"no":3,"type":"2","position":"absolute","imgelements":[{"no":4,"position":"absolute","type":"21","src":"4.mid","left":"0","top":"0","width":"1174","height":"1156","degs":"","moveable":"0","editable":"0"}],"left":"-227","top":"0","width":"1174","height":"1156","background_color":""},{"no":5,"type":"2","position":"absolute","imgelements":[{"no":6,"position":"absolute","type":"21","src":"6.mid","left":"0","top":"0","width":"675","height":"506","degs":"","moveable":"1","editable":"1"},{"no":7,"position":"absolute","type":"22","src":"7.mid","left":"0","top":"0","width":"675","height":"506","degs":"","moveable":"0","editable":"0"},{"no":8,"position":"absolute","type":"23","src":"8.mid","left":"0","top":"0","width":"675","height":"506","degs":"","moveable":"0","editable":"0"}],"left":"47","top":"211","width":"675","height":"506","background_color":""},{"no":9,"type":"1","position":"absolute","moveable":"0","editable":"0","text_align":"right","line_height":"normal","width":"600","height":"58","top":"980","left":"79","right":"0","bottom":"auto","background_color":"rgba(225, 252, 246, 0)","textelements":[{"no":10,"type":"11","position":"absolute","moveable":"0","editable":"1","color":"rgba(118,69,72,1)","text_align":"right","width":"600","height":"58","top":"0","left":"0","right":"auto","bottom":"auto","degs":"0","content":"出生-2岁3个月","font_size":"42px","line_height":"42px","isDateContent":"1"}]},{"no":11,"type":"2","position":"absolute","imgelements":[{"no":12,"position":"absolute","type":"21","src":"12.mid","left":"0","top":"0","width":"194","height":"193","degs":"","moveable":"0","editable":"0"}],"left":"563","top":"148","width":"194","height":"193","background_color":""},{"no":13,"type":"2","position":"absolute","imgelements":[{"no":14,"position":"absolute","type":"21","src":"14.mid","left":"0","top":"0","width":"581","height":"159","degs":"","moveable":"0","editable":"0"}],"left":"79","top":"792","width":"581","height":"159","background_color":""},{"no":15,"type":"2","position":"absolute","imgelements":[{"no":16,"position":"absolute","type":"21","src":"16.mid","left":"0","top":"0","width":"173","height":"239","degs":"","moveable":"0","editable":"0"}],"left":"-10","top":"51","width":"173","height":"239","background_color":""}]},{"no":21,"coverType":"2","delable":"2","elements":[{"no":22,"type":"0","position":"absolute","background_color":"#fff8d1"},{"no":23,"type":"2","position":"absolute","imgelements":[{"no":24,"position":"absolute","type":"21","src":"24.mid","left":"0","top":"0","width":"1174","height":"1156","degs":"","moveable":"0","editable":"0"}],"left":"-227","top":"0","width":"1174","height":"1156","background_color":""},{"no":25,"type":"2","position":"absolute","imgelements":[{"no":26,"position":"absolute","type":"21","src":"26.mid","left":"0","top":"0","width":"600","height":"324","degs":"","moveable":"0","editable":"0"}],"left":"60","top":"538","width":"600","height":"324","background_color":""}]}],"medias":{"4":{"src":"http://osscdn2.banketime.com/apk/_235614537180758827.png","type":"1","source":"1"},"6":{"src":"http://osscdn2.banketime.com/albums/_762414479908357346.jpeg","type":"1","source":"1"},"7":{"src":"http://osscdn2.banketime.com/apk/_864114537198913179.png","type":"1","source":"1"},"8":{"src":"http://osscdn2.banketime.com/apk/_618214537199120647.png","type":"1","source":"1"},"12":{"src":"http://osscdn2.banketime.com/apk/_483814537199454581.png","type":"1","source":"1"},"14":{"src":"http://osscdn2.banketime.com/apk/_46614537199724905.png","type":"1","source":"1"},"16":{"src":"http://osscdn2.banketime.com/apk/_771614537199999053.png","type":"1","source":"1"},"24":{"src":"http://osscdn2.banketime.com/apk/_235614537180758827.png","type":"1","source":"1"},"26":{"src":"http://osscdn2.banketime.com/apk/_35314537200851241.png","type":"1","source":"1"}}}');
        data.pages[0].coverType ||resetPageData(coverAlbums.pages[0],coverAlbums.medias);
        data.pages[data.pages.length - 1].coverType || resetPageData(coverAlbums.pages[1],coverAlbums.medias);
    }
    $.each(data.pages, function (i, c) {
        parm.pageno++;
        var pageno = parm.pageno;
        pageparm.pushPage(pageno);
        pagedata[pageno] = c;
        $.each(c.elements, function (i, c) {
            elementsData[c.no] = c;
            if (c.type == '2') {
                for (var k in c.imgelements) {
                    var cc = c.imgelements[k];
                    elementsData[cc.no] = cc;
                    if (cc.type == '21' && cc.editable == '1') {
                        imgedit.push(cc.no);
                        pageparm.imgPage[cc.no] = pageno;
                        pageparm.imgBox[cc.no] = c.no;
                        var src = cc.src.replace('.mid', '');
                        if (!(mediasData[src].source == '1'))
                            imghasedit.push(cc.no.toString());
                    }
                }
            }
            else if (c.type == '1') {
                for (var k in c.textelements) {
                    var cc = c.textelements[k];
                    elementsData[cc.no] = cc;
                }
            }
        });
    });
    createpage(pageparm.pagelist[0]);
}
function createpage(pageno) {
    if (!(pageno && $.inArray(pageno, pageparm.pageloaded) == -1)) {
        if (parm.currentpage == pageno) {
            $('.page').removeClass('pagenow');
            $('#page' + pageno).addClass('pagenow');
        }
        return;
    }
    var getpageafter = function (pageno) {
        var after, list = pageparm.pagelist;
        for (var i = list.indexOf(pageno); i < list.length; i++) {
            after = list[i];
            if ($('#page' + after).length > 0)
                return after;
        }
        return false;
    };
    var loadingImg = function () {
        var pageimg = {};
        $.each(data.elements, function (i, c) {
            switch (c.type) {
                case '0':
                    if (c.background_img)
                        pageimg[c.no] = {"src": c.background_img,'type':'0', 'w':jsonOrg.width,'h':jsonOrg.height, 'reWH': 0};
                    break;
                case '1':
                    for (var k in c.textelements) {
                        var cc = c.textelements[k];
                        if (cc.type == '12')
                            pageimg[cc.no] = {"src": cc.src,'type':'12', 'w':cc.width,'h' : cc.height,'reWH': 0};
                        else if(cc.type == '11'&&cc.src)
                            pageimg[cc.no] = {"src": cc.src,'type':'11', 'w':c.width,'h' : c.height,  'reWH': 0};
                    }
                    break;
                case '2':
                    for (var k in c.imgelements) {
                        var cc = c.imgelements[k];
                        var width,height, reWH;
                        if (cc.width && cc.height) {
                            width = cc.width;
                            height = cc.height;
                            reWH = 0;
                        }
                        else {
                            width = c.width;
                            height = c.height;
                            reWH = 1;
                        }
                        pageimg[cc.no] = {"src": cc.src,'type':cc.type, 'w': width,'h' : height, 'reWH': reWH};
                    }
                    break;
            }
        });
        imglist[pageno] = {};
        for (var k in pageimg) {
            pageimg[k].src = getImgSrc(pageimg[k].src, pageimg[k].w);
        }
        var jsStr = JSON.stringify({'pageno': pageno, 'pageimgs': pageimg});
        if (isClient)
            window.magazine.loadImg(jsStr);
        else
            loadImg(jsStr);
    };
    var data = pagedata[pageno];
    var html = '<div class="page" id="page' + pageno + '" style="z-index:0;position: absolute;width: 100%;height: 100%;"><div class="box" style="position: relative;width: 100%;height: 100%;"></div></div>';
    var afterpage = getpageafter(pageno);
    if (!afterpage) {
        if ($('.lastpage').length > 0)
            $('.lastpage').before(html);
        else if ($('#pageadd').length > 0)
            $('#pageadd').before(html);
        else
            $('.pagesbox').append(html);
    }
    else {
        $('#page' + afterpage).before(html);
    }
    pageparm.pageloaded.push(pageno);
    if (parm.currentpage == pageno) {
        $('.page').removeClass('pagenow');
        $('#page' + pageno).addClass('pagenow');
    }
    setdisplay(haszoom);
    if(parm.printtype==3)
    {
        var pagew = $('#page' + pageno).width(),pageh = $('#page' + pageno).height(),left = parseInt((pagew-pageh)/2);
        $('#page' + pageno).find('.box').before('<div style="position: absolute;left: '+left+'px;width: '+pageh+'px;height:'+pageh+'px;background-color: #FFFFFF"></div>');
    }
    if (data.delable) {
        $('#page' + pageno).attr('_delable', data.delable);
    }
    loadingImg();
}
function loadImg(param) {
    var js = JSON.parse(param);
    var pageNo = js.pageno;
    var pageImgs = js.pageimgs;
    var imgOnload = function (imgdata, imgno) {
        if (!imglist[pageNo]) return;
        var imgsrc = imgdata.src;
        var img = new Image();
        img.src = imgsrc;
        img.onload = function () {
            if (imgdata.reWH == '1') {
                var w = getScaleValue(imgdata.w);
                var h = getScaleValue(imgdata.h);
                var scalew = w / img.width;
                var scaleh = h / img.height;
                var scale = scalew > scaleh ? scalew : scaleh;
                var left = scale == scaleh ? (w - img.width * scale) / 2 : 0;
                var top = scale == scalew ? (h - img.height * scale) / 2 : 0;
                w = img.width * scale;
                h = img.height * scale;
                elementsData[imgno].width = pageScale.Divide(w).toString();
                elementsData[imgno].height = pageScale.Divide(h).toString();
                elementsData[imgno].left = pageScale.Divide(left).toString();
                elementsData[imgno].top = pageScale.Divide(top).toString();
                delete elementsData[imgno].right;
                delete elementsData[imgno].bottom;
            }
            if (imglist[pageNo]) {
                imglist[pageNo][imgno] = this;
                if (count(imglist[pageNo]) == imgcount)
                    callback();
            }
        }
        img.onerror = function () {
            if (imglist[pageNo]) {
                imglist[pageNo][imgno] = false;
                if (count(imglist[pageNo]) == imgcount)
                    callback();
            }
        }
    };
    var callback = function () {
        var page = $('#page' + pageNo).find('.box');
        $.each(pagedata[pageNo].elements, function (i, c) {

            var imgdata = reSetData(c);
            switch (c.type) {
                case '0':
                    setbackground(page, pageNo, imgdata);
                    break;
                case '1':
                    settextbox(page, pageNo, imgdata);
                    break;
                case '2':
                    setimgbox(page, pageNo, imgdata);
                    break;
            }
        });
        onElement();
        setdisplay(haszoom);
        if (!windowLoad && $('.page').hasClass('pagenow')) {
            windowloaded();
            loadpage();
        }
    };
    var imgcount = count(pageImgs);
    for (var k in pageImgs) {
        imgOnload(pageImgs[k], k);
    }
}
function reSetData(data) {
    var redata = {};
    redata.no = data.no;
    redata.type = data.type;
    data.background_color && (redata.color = data.background_color);
    if (data.type == '0') {
        redata.w = '100%';
        redata.h = '100%';
        redata.position = 'absolute';
        redata.src = data.background_img;
        redata.color = data.background_color == 'rgba(0, 0, 0, 0)' ? '#fff' : data.background_color;
        return redata;
    }
    redata.w = getScaleValue(data.width);
    redata.h = getScaleValue(data.height);
    redata.scale = data.scales || 1;
    if (!parm.newAlbums && !data.ver) {
        redata.translatex = pageScale.Divide(data.translate_x || 0);
        redata.translatey = pageScale.Divide(data.translate_y || 0);
        elementsData[data.no].translate_x = redata.translatex;
        elementsData[data.no].translate_y = redata.translatey;
        setEditVer(data.no);
    }
    redata.translatex = getScaleValue(data.translate_x || 0);
    redata.translatey = getScaleValue(data.translate_y || 0);
    redata.degs = data.degs || 0;
    redata.position = data.position;
    redata.left = getScaleValue(data.left);
    redata.top = getScaleValue(data.top);
    redata.right = getScaleValue(data.right);
    redata.bottom = getScaleValue(data.bottom);
    redata.moveable = data.moveable;
    redata.editable = data.editable;
    switch (data.type) {
        case '1':
            redata.cssclass = data.cssclass;
            redata.textalign = data.text_align;
            redata.textelements = data.textelements;
            break;
        case '2':
            redata.cssclass = data.cssclass;
            redata.imgelements = data.imgelements;
            break;
        case '11':
            if (data.src) {
                redata.src = data.src;
            }
            else {
                redata.fontsize = getScaleValue(data.font_size.replace('px', '')) + 'px';
                redata.lineheight = getScaleValue(data.line_height.replace('px', '')) + 'px';
                data.color && (redata.fontcolor = data.color);
            }
            data.editDate && (redata.editDate = data.editDate);
            redata.content = data.content;
            redata.marginleft = getScaleValue(data.margin_left);
            redata.margintop = getScaleValue(data.margin_top);
            redata.marginright = getScaleValue(data.margin_right);
            redata.marginbottom = getScaleValue(data.margin_bottom);
            redata.border_style = data.border_style;
            redata.border_color = data.border_color;
            redata.border_width = data.border_width;
            redata.z_index = 99;
            break;
        case '12':
            redata.marginleft = getScaleValue(data.margin_left);
            redata.margintop = getScaleValue(data.margin_top);
            redata.marginright = getScaleValue(data.margin_right);
            redata.marginbottom = getScaleValue(data.margin_bottom);
            redata.src = data.src;
            redata.z_index = -1;
            break;
        case '22':
            redata.src = data.src;
            redata.z_index = 99;
            break;
        case '21':
            redata.src = data.src;
            break;
        case '23':
            redata.src = data.src;
            break;
    }
    return redata;
}
function setEditVer(eleno) {
    elementsData[eleno].ver = 's1_' + pageScale.value.toFixed(4);
}
function getImgSrc(orgsrc, w) {
    var index = orgsrc ? orgsrc.replace('.mid', '') : -1;
    var url = '';
    if (mediasData[index]) {
        url = mediasData[index].src;
        if (isClient==false && w) {
            if (url.lastIndexOf(".png") == -1 && url.lastIndexOf(".gif") == -1) {
                var index = url.indexOf("http://osscdn.banketime.com");
                if (index != -1) {
                    url = url.replace("http://osscdn.banketime.com", "http://osscdn2.banketime.com");
                } else {
                    index = url.indexOf("http://osscdn2.banketime.com");
                }
                if (index != -1) {
                    if (url.indexOf("_min.") != -1) {
                        url = url.replace("_min.", ".");
                    }
                    index = url.lastIndexOf("@");
                    if (index != -1)
                        url = url.substring(0, index);
                    //var wnew = parseInt(getScaleValue(w) * 1.5);
                    url = url + "@" + w + "w_" + w + "h_1l" + ".jpg";
                }
                ;
            }
        }
    }
    return url;
}
function getScaleValue(v) {
    return pageScale.Multiply(v);
}
function baseBox(parent, data) {
    var no = data.no;
    var width = data.w;
    var height = data.h ? data.h : 'auto';
    width = !isNaN(width) ? width + 'px' : width;
    height = !isNaN(height) ? height + 'px' : height;
    var html = '<div id="element' + no + '" style="width:' + width + ';height:' + height + ';background-size: 100% 100%;"></div> ';
    parent.append(html);
    var box = $('#element' + no);
    var position = data.position;
    if (position) {
        var top = data.top + 'px' || 'auto';
        var left = data.left + 'px' || 'auto';
        var right = data.right + 'px' || 'auto';
        var bottom = data.bottom + 'px' || 'auto';
        box.css({'position': position, 'top': top, 'left': left, 'right': right, 'bottom': bottom});
    }
    if (data.color && !(data.type == '2'))
        box.css('background-color', data.color);
    data.z_index?box.css('z-index', data.z_index):box.css('z-index', 1);
    var margintop = data.margintop + 'px' || 'auto';
    var marginleft = data.marginleft + 'px' || 'auto';
    var marginright = data.marginright + 'px' || 'auto';
    var marginbottom = data.marginbottom + 'px' || 'auto';
    box.css({
        'margin-top': margintop,
        'margin-left': marginleft,
        'margin-right': marginright,
        'margin-bottom': marginbottom
    });
    box.attr({'_type': data.type, '_moveable': data.moveable, '_editable': data.editable});
    box.css({
        scale: data.scale,
        translate: [data.translatex + 'px', data.translatey + 'px'],
        rotate: data.degs + 'deg'
    });
    return box;
}
function setbackground(page,pageno, data) {
    var bg = baseBox(page, data);
    bg.css('z-index', '0');
    if (imglist[pageno][data.no]) {
        bg.css('background-image', 'url(' + imglist[pageno][data.no].src + ')');
    }
}

function settextbox(page,pageno, data) {
    var box = baseBox(page, data);
    var text_align = data.textalign;
    var z_index = data.z_index || 999;
    data.cssclass && addAnimate(box, 'opacity_init', true);
    box.css({'z-index': z_index, 'text-align': text_align});
    $.each(data.textelements, function (i, c) {
        var redata = reSetData(c);
        if (c.type == '11')
            setTextEl(box,pageno ,redata);
        else if (c.type == '12')
            setImgEl(box,pageno, redata);
    });

}
function addAnimate(e, cssclass, add) {
    if (cssclass) {
        add ? e.addClass(cssclass) : e.removeClass(cssclass);
    }
}
function showAnimate(pageno, add) {
    if (!isNaN(pageno)&&pageno>0) {
        var data = pagedata[pageno];
        $.each(data.elements, function (i, c) {
            switch (c.type) {
                case '1':
                case '2':
                    addAnimate($('#element' + c.no), c.cssclass, add);
                    break;
            }
        });
        $('#page' + pageno).find('div[_type="11"][_editable="1"]').each(function () {
            var cssclass = 'editprompt';
            if (haszoom)
                $(this).hasClass(cssclass) || addAnimate($(this), cssclass, true);
        });
    }

}
function setimgbox(page, pageno, data) {
    var img = false, box = baseBox(page, data);
    data.cssclass && addAnimate(box, 'opacity_init', true);
    $.each(data.imgelements, function (i, c) {
        if (c.type == '21') {
            img = c;
        }
    });
    if (!img) return;
    if (img.editable != '1') {
        var redata = reSetData(img);
        setImgEl(box,pageno, redata);
    }
    else {
        $.each(data.imgelements, function (i, c) {
            var src = getImgSrc(c.src, data.w);
            box.append('<img style="display: none;" src="' + src + '" height="200" width="200" />');
        });
        var html = '<canvas id="element' + img.no + '"></canvas> ';
        box.append(html);
        var mc = document.getElementById("element" + img.no);
        mc.width = data.w * parm.ratio;
        mc.height = data.h * parm.ratio;
        pageparm.myCanvas[pageno] || (pageparm.myCanvas[pageno] = {});
        var mcc = pageparm.myCanvas[pageno];
        mcc[img.no] = {};
        mcc[img.no].canvas = mc;
        mcc[img.no].ctx = mc.getContext('2d');
        $("#element" + img.no).attr({
            '_type': img.type,
            '_moveable': img.moveable,
            '_editable': img.editable
        }).css({'width': data.w, 'height': data.h});
        drawImg(img.no, pageno);
    }
}
function moveElement(no, x, y) {
    var e = $('#element' + no);
    if (e[0].tagName == 'CANVAS')
        moveImg(no, x, y)
    else {
        e.css({
            transform: ''
        }).css({
            translate: [x + 'px', y + 'px'],
            rotate: (elementsData[no].degs || 0) + 'deg',
            scale: (elementsData[no].scales || 1)
        });
        elementsData[no].translate_x = x;
        elementsData[no].translate_y = y;
    }
}
function scaleElement(no, scales) {
    var e = $('#element' + no);
    if (e[0].tagName == 'CANVAS')
        scaleImg(no, scales);
    else {
        e.css({
            scale: scales
        });
    }
}
function scaleImg(imgno, scales) {
    var oldscales = (elementsData[imgno].scales || 1);
    var changescales = scales - oldscales;
    elementsData[imgno].translate_x = ((elementsData[imgno].translate_x || 0) * oldscales - changescales * elementsData[imgno].width / 2) / scales;
    elementsData[imgno].translate_y = ((elementsData[imgno].translate_y || 0) * oldscales - changescales * elementsData[imgno].height / 2) / scales;
    elementsData[imgno].scales = scales;
    drawImg(imgno, parm.currentpage);
}
function moveImg(imgno, x, y) {
    elementsData[imgno].translate_x = pageScale.Divide(x);
    elementsData[imgno].translate_y = pageScale.Divide(y);
    drawImg(imgno, parm.currentpage);
}

function reDrawCanvas() {
    var dodraw = function () {
        var no = $(this).attr('id').replace('element', '');
        var imgno = elementsData[no].src.replace('.mid', '');
        if (mediasData[imgno].source == '1') {
            var page = currentPage($(this));
            var pageno = page.attr('id').replace('page', '');
            drawImg(no, pageno);
        }
    }
    $('.pagenow').find('canvas[_editable="1"]').each(dodraw);
    $('.page:not([class*="pagenow"])').find('canvas[_editable="1"]').each(dodraw);
}

function drawImg(imgno, pageno) {
    var boxno = $('#element' + imgno).parent().attr('id').replace('element', '');
    var data = reSetData(elementsData[boxno]);
    var mask, img, spemask;
    $.each(data.imgelements, function (i, c) {
        var redata = reSetData(elementsData[c.no]);
        redata.left = redata.left || (redata.right > 0 && (redata.position == 'absolute' ? (data.w - redata.w - redata.right) : (0 - redata.right))) || 0
        redata.top = redata.top || (redata.bottom > 0 && (redata.position == 'absolute' ? (data.h - redata.h - redata.bottom) : (0 - redata.bottom))) || 0
        if (redata.type == '21')
            img = redata;
        else if (redata.type == '22')
            mask = redata;
        else if (c.type == '23')
            spemask = redata;
    });
    var mc = pageparm.myCanvas[pageno][imgno].canvas;
    pageparm.myCanvas[pageno][imgno].ctx.clearRect(0, 0, mc.width, mc.height);
    if (data.color) {
        pageparm.myCanvas[pageno][imgno].ctx.fillStyle = data.color;
        pageparm.myCanvas[pageno][imgno].ctx.fillRect(0, 0, mc.width, mc.height);
    }
    if (img) {
        img.canvasW = mc.width > mc.height ? mc.height : mc.width;
        setCanvasImg(imgno, img, pageno, 1);
    }
    if (spemask)
        setCanvasImg(imgno, spemask, pageno, 3);
    if (mask)
        setCanvasImg(imgno, mask, pageno, 2);
}
function setTextEl(box,pageno, textdata) {
    var text = baseBox(box, textdata);
    if (textdata.src) {
        text.css({
            'position': 'absolute',
            'width': '100%',
            'height': '100%',
            'margin': 'auto',
            'padding': 'auto',
            'background-image': 'url(' + imglist[pageno][textdata.no].src + ')'
        })
    }
    else {
        text.html(textdata.content);
        var fontsize = textdata.fontsize;
        var lineheight = textdata.lineheight;
        text.css({'font-size': fontsize, 'line-height': lineheight});
        textdata.fontcolor && (text.css('color', textdata.fontcolor));
        text.css({
            'border-style': textdata.border_style,
            'border-color': textdata.border_color,
            'border-width': textdata.border_width
        });
        textdata.editDate && (text.attr('_editDate', textdata.editDate))

    }
}
function setImgEl(box,pageno, imgdata) {
    var img = baseBox(box, imgdata);
    if (box.css('text-align') == 'center') img.css('margin', '0 auto');
    img.css('background-image', 'url(' + imglist[pageno][imgdata.no].src + ')');
}
function setCanvasImg(imgno, imgdata, pageno, type) {
    var mc = pageparm.myCanvas[pageno][imgno].canvas;
    var cxt = pageparm.myCanvas[pageno][imgno].ctx;
    var w = imgdata.w * parm.ratio;
    var h = imgdata.h * parm.ratio;
    var x = imgdata.left * parm.ratio;
    var y = imgdata.top * parm.ratio;
    var img = imglist[pageno][imgdata.no];
    if (img) {
        cxt.save();
        if (type == 2) {
            x -= 1, y -= 1, w += 2, h += 2;
            cxt.globalCompositeOperation = "source-over";
        }
        else if (type == 3) {
            x -= 1, y -= 1, w += 2, h += 2;
            cxt.globalCompositeOperation = "destination-in";
        }
        if (Number(imgdata.degs) > 0 || Number(imgdata.degs) < 0) {
            cxt.translate(x + w / 2, y + h / 2);
            cxt.rotate(imgdata.degs * Math.PI / 180);
            x = -w / 2;
            y = -h / 2;
        }
        var scale = imgdata.scale || 1;
        if (scale != 1)
            cxt.scale(scale, scale);
        x += imgdata.translatex * parm.ratio;
        y += imgdata.translatey * parm.ratio;
        cxt.drawImage(img, x, y, w, h);
        if(type == 1 && haszoom) {
            if (($.inArray(parm.printtype, [0, 3]) > -1) && mediasData[imgdata.src.replace('.mid', '')].source == '1') {
                var tagw = mc.width / scale;
                var tagh = mc.height / scale;
                cxt.fillStyle = 'rgba(0,0,0,0.4)';
                cxt.fillRect(0, 0, tagw, tagh);
                var tagIconW = tagw * 0.2;
                cxt.drawImage(cacheImg.addImgTagIcon, (tagw - tagIconW) / 2, (tagh - tagIconW) / 2, tagIconW, tagIconW);
            }
            else if (parm.printtype == 3 && mediasData[imgdata.src.replace('.mid', '')].source !== '1') {
                var imgW = (mediasData[imgno].width||0),imgH = (mediasData[imgno].height||0);
                if (imgW<480||imgH<480)
                {
                    var tagw = mc.width / scale;
                    var tagh = mc.height / scale;
                    cxt.fillStyle = 'rgba(0,0,0,0.4)';
                    cxt.fillRect(0, 0, tagw, tagh);
                    var tagIconW = tagw * 0.2;
                    cxt.drawImage(cacheImg.errImgTagIcon, (tagw - tagIconW) / 2, (tagh - tagIconW) / 2, tagIconW, tagIconW);
                }
            }
        }
        cxt.restore();
    }
}

function count(o) {
    var t = typeof o;
    if (t == 'string') {
        return o.length;
    } else if (t == 'object') {
        var n = 0;
        for (var i in o) {
            n++;
        }
        return n;
    }
    return false;
}
function resetPageData(pageData,medias)
{
    var resetno = function(d) {
        d.no = parm.newno;
        parm.newno++;
        return d;
    };
    var resetSrc = function(d, md) {
        if (d.src) {
            var srcno = d.src.replace('.mid', '');
            d.src = d.no + '.mid';
            mediasData[d.no] = md[srcno];
        }
        if (d.background_img) {
            var srcno = d.background_img.replace('.mid', '');
            d.background_img = d.no + '.mid';
            mediasData[d.no] = md[srcno];
        }
        return d;
    }
    var pageno = ++parm.pageno;
    $.each(pageData.elements, function (i, c) {
        c = resetno(c);
        c = resetSrc(c, medias);
        elementsData[c.no] = c;
        if (c.type == '1') {
            $.each(c.textelements, function (ii, cc) {
                cc = resetno(cc);
                cc = resetSrc(cc, medias);
                elementsData[cc.no] = cc;
            });
        }
        else if (c.type == '2') {
            $.each(c.imgelements, function (ii, cc) {
                cc = resetno(cc);
                cc = resetSrc(cc, medias);
                elementsData[cc.no] = cc;
                if (cc.type == '21' && cc.editable == '1') {
                    imgedit.push(cc.no);
                    pageparm.imgPage[cc.no] = pageno;
                    pageparm.imgBox[cc.no] = c.no;
                    var src = cc.src.replace('.mid', '');
                    if (!(mediasData[src].source == '1'))
                        imghasedit.push(cc.no.toString());
                }
            });
        }

    });
    pageparm.pushPage(pageno);
    pagedata[pageno] = pageData;
    return pageno;
}
function addnewpage(no,albums) {
    var temp = albums||albumstemp;
    if (!temp) return;
    var data = JSON.parse(temp);
    var pd;
    $.each(data.pages, function (i, c) {
        if (no == c.no) {
            pd = c;
            return false;
        }
    });
    if (pd) {
        var medias = data.medias;

        var pageno = resetPageData(pd,medias);
        parm.currentpage = pageno;
        createpage(pageno);
        loadpage();
    }
}
function setAlbumsTemp(id) {
    var temp = '';
    var storage = window.localStorage;
    if (storage) {
        temp = storage.getItem('albumstemp_' + id) || '';
        if (temp) {
            var settime = JSON.parse(temp).settime || 0;
            if ((new Date().getTime()) - settime < 3600000) {
                albumstemp = temp;
                console.log('storage');
                return;
            }
        }
    }
    $.ajax({
        type: "get",
        url: templeUrl + 'view/albumstemp',
        data: {
            id: id
        },
        dataType: "json",
        success: function (data) {
            var jd = data.data.temp;
            var jdobject = JSON.parse(jd);
            jdobject.settime = new Date().getTime();
            albumstemp = JSON.stringify(jdobject);
            storage && storage.setItem('albumstemp_' + id, albumstemp);
        },
        error: function () {
            setAlbumsTemp(id);
        }
    });
}

function setCustomAlbums() {
    if (parm.printtype==3 && !parm.customAlbums) {
        var temp = '';
        var storage = window.localStorage;
        if (storage) {
            temp = storage.getItem('myCustomAlbums') || '';
            if (temp) {
                var settime = JSON.parse(temp).settime || 0;
                if ((new Date().getTime()) - settime < 3600000) {
                    parm.customAlbums = temp;
                    return;
                }
            }
        }
        $.ajax({
            type: "get",
            url: templeUrl + 'view/customalbums',
            data: {},
            dataType: "json",
            success: function (data) {
                var jd = data.data.albums;
                var jdobject = JSON.parse(jd);
                jdobject.settime = new Date().getTime();
                parm.customAlbums = JSON.stringify(jdobject);
                storage && storage.setItem('myCustomAlbums', parm.customAlbums);
            },
            error: function () {
                setCustomAlbums();
            }
        });
    }
}

var Storage = {
    name: "albums",
    get: function (a) {
        if (/[&\\=\|\?%]/.test(a)) alert("name\u4e0d\u80fd\u5305\u542b\u7279\u6b8a\u7b26\u53f7");
        else if (window.localStorage && (a = (window.localStorage[this.name] || "").match(RegExp("(?:^|&)" + a + "=([^&]*)")))) return decodeURIComponent(a[1])
    },
    set: function (a, b) {
        if (/[&\\=\|\?%]/.test(a)) return alert("name\u4e0d\u80fd\u5305\u542b\u7279\u6b8a\u7b26\u53f7"), !1;
        if (window.localStorage) {
            var c = window.localStorage[this.name] || "",
                c = void 0 === this.get(a) ? c + (("" === c ? "" : "&") + a + "=" + b.replace(/&/g, "%26").replace(/=/g, "%3D")) : c.replace(RegExp("(^|&)" + a + "=([^&]*)"), "$1" + a + "=" + encodeURIComponent(b));
            window.localStorage[this.name] = c;
            return !0
        }
        return !1
    },
    del: function (a) {
        if (/[&\\=\|\?%]/.test(a)) return alert("name\u4e0d\u80fd\u5305\u542b\u7279\u6b8a\u7b26\u53f7"), !1;
        if (window.localStorage && void 0 !== this.get(a)) {
            var b = window.localStorage[this.name] || "",
                b = b.replace(RegExp("(^|&)" + a + "=([^&]*)"), "");
            window.localStorage[this.name] = b.replace(/^&/, "");
            return !0
        }
        return !1
    },
    clear: function () {
        window.localStorage && (window.localStorage[this.name] = "")
    }
};