var mousemove = false, haszoom = false, mediasData = {}, imgedit = [], imghasedit = [], timestamp = 0, isEdited = false, uicon = './image/babyZone.png', uname = '宝宝助手用户', windowLoad = false, templeUrl = '/', itemcontentmove = false, clientVersion = 0;
var isClient, isClientIn, zoomOrg, editElement, jsondata, make, share, heightOrg, widthOrg, jsonOrg;
var clientCode = '', clientVersion = '';
// 评论相关
var bbrecord_id = 0;
var user_id = 0;
var defaultCont = '说点什么，关爱一下吧';
var page = 0;
var to_uid = 0;
var to_rcid = 0;
var inter = '';
var comm_count = 0;
// end
var content_count = 0;
$(document).ready(function () {
	setClient(true);
    heightOrg = $(window).height();
    $("body").height(heightOrg);
    widthOrg = $(window).width();
    if (isClient) {
        templeUrl = "http://admin.banketime.com/";
        $('.loadingPage').css('display', 'none');
        window.magazine.initData();
    }
    else {
        $('.loadingBar').css('padding-top', heightOrg / 2 - 40 + 'px');
        jsonDataToHtml(jsondata, make, make, make, 0);
        jsonOrg.icon && $('.shareimg img').attr('src', jsonOrg.icon);
        $(document).attr("title", jsonOrg.title);
        $(document).on('touchstart', function () {
            if (!isClient && $('.playmusic img').hasClass('play')) {
                audio = $('audio')[0];
                if (audio.paused) {
                    audio.play();
                }
            }
        });
    }
    $("body").on('touchmove', '.item_content', function (event) {
        itemcontentmove = true;
        var touch = e.touches[0];
    });
    $("body").on('touchend', '.item_content', function (event) {
        itemcontentmove = false;
    });
    $("body").on('touchend', '.item', function (event) {
        if (!itemcontentmove) {
            var pageno = $(this).find('.item_img').attr('_pageno');
            if ($(this).parent().parent().hasClass('tab2items')) {
                addnewpage(pageno, parm.customAlbums);
                if (parm.printtype != 0)
                    window.magazine.addPage('{"type": "2"}');
            }
            else {
                addnewpage(pageno);
                if (parm.printtype != 0)
                    window.magazine.addPage('{"type": "1"}');
            }

            $('.pagenobox').remove();
        }
    });
    $("body").on('touchend', '.tabs', function () {
        $('.selectedtab').removeClass('selectedtab');
        $(this).addClass('selectedtab');
        if ($(this).hasClass('tab1')) {
            $('.tab1items').addClass('items_selected');
            $('.tab2items').removeClass('items_selected');
        }
        else {
            $('.tab2items').addClass('items_selected');
            $('.tab1items').removeClass('items_selected');
        }
    });

//     // 评论函数
//     comment_function();
});
function setParm(parmJson) {
    var parmArr = JSON.parse(parmJson);
    templeUrl = parmArr.templeUrl;
    clientVersion = parseInt(parmArr.clientversion);
    parmArr.bbrecord_id && (bbrecord_id = parmArr.bbrecord_id);
    parmArr.user_id && (user_id = parmArr.user_id);
    parmArr.isSupportAlbumPrint && (parm.isSupportAlbumPrint = parmArr.isSupportAlbumPrint);
}
// function
function windowloaded() {
    if (windowLoad) {
        return;
    }
    windowLoad = true;
    pageZoom(haszoom);
    appendFile();
    playaudio();
//	// 加载评论 start
//	if(bbrecord_id)
//		comment_list(page, bbrecord_id);
//	if(comm_count > 5)
//		inter = commScroll();
//	else
//	{
//		$("#comment_ul").find("li").css('opacity', '1');
//	}
//	
//	$("#comment_list").hide();
//	$(".open_comment").css('bottom', $("#add").height()+20);
//	$("#comment_list").css('bottom', $("#add").height()+$(".open_comment").height()+40);
//	$("#add").hide();
//	//console.log('org'+zoomOrg);
//	if(!zoomOrg && bbrecord_id)
//	{
//		$(".open_comment").show();
//	}
//	else
//		$(".open_comment").hide();
//	// end

    if (isClient)
        window.magazine.isLoaded(true);
    else {
        $('.loadingPage').css('display', 'none');
        if (!make && !share && window.localStorage && (localStorage.thisyearId == GetRequest()['key']))
            appendShare();
    }
    if ($.inArray(parm.printtype, [0, 3]) > -1 && !albumstemp) {
        setAlbumsTemp(jsonOrg.id);
        if (parm.printtype == 3)
            setCustomAlbums();
    }
}
var handleTouchyPinch = function (e, $target, data) {
    if (haszoom) {
        var timeStamp = new Date().getTime();
        if (dragTimeStamp + 15 < timeStamp) {
            var e = getEditElement($target);
            var id = e.attr('id').replace('element', '');
            var scales = elementsData[id]['scales'] || 1;
            if (!(elementsData[id].editMask && elementsData[id].editMask == 2 && $.inArray(id, imghasedit) == -1)) {
                mousemove = true;
                isEdited = true;
                scales += data.scale - data.previousScale;
                scales = scales <= 0.3 ? 0.3 : (scales > 3 ? 3 : scales);
                scaleElement(id, scales)

                elementsData[id]['scales'] = scales;
                setEditVer(id);
            }
        }
        dragTimeStamp = timeStamp;
    }
}
var touchydrag = false, translate_x, translate_y, dragstartx, dragstarty, moveEleId, dragTimeStamp = 0;
var handleTouchyDrag = function (event, phase, $target, data) {
    if (haszoom) {
        var timeStamp = new Date().getTime();
        if (dragTimeStamp + 15 < timeStamp) {
            var movePoint = data.movePoint,
                startPoint = data.startPoint;
            switch (phase) {
                case 'start':
                    var e = getEditElement($target);
                    moveEleId = e.attr('id').replace('element', '');
                    if (!(elementsData[moveEleId].editMask && elementsData[moveEleId].editMask == 2 && $.inArray(moveEleId, imghasedit) == -1)) {
                        touchydrag = true;
                        dragstartx = getScaleValue(elementsData[moveEleId].translate_x || 0) * (elementsData[moveEleId].scales || 1);
                        dragstarty = getScaleValue(elementsData[moveEleId].translate_y || 0) * (elementsData[moveEleId].scales || 1);
                    }
                    break;
                case 'move':
                    if (touchydrag) {
                        mousemove = true;
                        isEdited = true;
                        var elScale = (elementsData[moveEleId].scales || 1);
                        translate_x = parseInt((dragstartx + movePoint.x - startPoint.x) / elScale);
                        translate_y = parseInt((dragstarty + movePoint.y - startPoint.y) / elScale);
                        if (elementsData[moveEleId].type == '21') {
                            var left = pageScale.Multiply(elementsData[moveEleId].left * elScale), top = pageScale.Multiply(elementsData[moveEleId].top * elScale);
                            var parentW = $('#element' + moveEleId).parent().width();
                            var parentH = $('#element' + moveEleId).parent().height();
                            var thisW = pageScale.Multiply(elementsData[moveEleId].width * elScale);
                            var thisH = pageScale.Multiply(elementsData[moveEleId].height * elScale);
                            if (thisW <= parentW) {
                                (parseInt(translate_x * elScale) + left > 0) || (translate_x = -parseInt(left / elScale));
                                if (thisW + left + parseInt(translate_x * elScale) > parentW) {
                                    translate_x = parseInt((parentW - left - thisW) / elScale);
                                }
                            }
                            else {
                                (parseInt(translate_x * elScale) + left < 0) || (translate_x = -parseInt(left / elScale));
                                if (thisW + left + parseInt(translate_x * elScale) < parentW) {
                                    translate_x = parseInt((parentW - left - thisW) / elScale);
                                }
                            }
                            if (thisH <= parentH) {
                                (parseInt(translate_y * elScale) + top > 0) || (translate_y = -parseInt(top / elScale));
                                if (thisH + top + parseInt(translate_y * elScale) > parentH) {
                                    translate_y = parseInt((parentH - top - thisH) / elScale);
                                }
                            }
                            else {
                                (parseInt(translate_y * elScale) + top < 0) || (translate_y = -parseInt(top / elScale));
                                if (thisH + top + parseInt(translate_y * elScale) < parentH) {
                                    translate_y = parseInt((parentH - top - thisH) / elScale);
                                }
                            }
                        }
                        //e.css({
                        //    transform: ''
                        //});
                        moveElement(moveEleId, translate_x, translate_y);
                    }
                    break;
                case 'end':
                    if (touchydrag) {
                        touchydrag = false;
                        setEditVer(moveEleId);
                    }
                    break;
            }
        }
        dragTimeStamp = timeStamp;
    }
}
var handleTouchyEnd = function () {
    if (haszoom && mousemove == false && Date.parse(new Date()) - timestamp > 1) {
        switch ($(this).attr('_type')) {
            case '11':
                var id = $(this).attr('id');
                var val = $(this).html();
                var maxlen = $(this).attr('_txtmaxlen');
                var no = id.replace('element', '');
                if (isClient) {
                    if (elementsData[no].src) {
                        if (clientVersion < 250) {
                            alert('请更新最新客户端，以获得最佳体验');
                            return;
                        }
                        var parentno = $(this).parent().attr('id').replace('element', '');
                        val = elementsData[no].content;
                        var color = elementsData[no].color;
                        var align = (elementsData[parentno].text_align == 'left' && '0') || (elementsData[parentno].text_align == 'center' && '2') || '1';
                        var minRowSize = elementsData[no].minrowsize;
                        var maxRowSize = elementsData[no].maxrowsize;
                        var fontId = elementsData[no].fontid;
                        var width = elementsData[parentno].width.toString();
                        var height = elementsData[parentno].height.toString();
                        window.magazine.editTextFont(id, val, color, align, minRowSize, maxRowSize, fontId, width, height);
                    }
                    else if (elementsData[no].editDate == '1') {
                        var oldTime = elementsData[no].timeStamp || 0;
                        window.magazine.selectTime(JSON.stringify({'elementId': id, 'oldTime': oldTime}));
                    }
                    else
                        window.magazine.editText(id, val, maxlen);

                }
                else {
                    if (!elementsData[no].src) {
                        editElement = $(this);
                        appendTextEdit();
                    }
                }
                break;
            case '21':
                id = $(this).attr('id');
                if (isClient)
                    window.magazine.editImg(id);
                else {
//					Ta.clickStat('替换图片');
                    editElement = $(this);
                    $("#bkf").click();
                }
                break;
            case '22':
                var imgEle = getEditElement($(this));
                id = imgEle.attr('id');
                if (isClient)
                    window.magazine.editImg(id);
                else {
                    editElement = imgEle;
                    $("#bkf").click();
                }
                break;
        }
    }
    timestamp = Date.parse(new Date());
    touchydrag = false;
    mousemove = false;
}
var pagedel = function () {
    if ($(".page[id!='pageadd']").length == 1) {
        alert('不能删除了，请至少保留一页');
        return;
    }
    if (!confirm('确定删除当前的页面？'))
        return;
    var index = $(".page").index($(".pagenow"));
    delpage(index);
    setdisplay(haszoom);
    isEdited = true;
}

function setClient(set) {
    isClient = set;
}
function setUserInfo(jsUinfo) {
    var uinfo = JSON.parse(jsUinfo);
    jsonOrg.uInfo || (jsonOrg.uInfo = {});
    jsonOrg.uInfo = uinfo;
}
function getEditElement(e) {
    if (e.attr('_type') == 22) {
        return e.parent().find('[_type="21"]')
    }
    if (e.attr('_moveable') == '1') {
        return e;
    } else {
        return getEditElement(e.parent());
    }
}

function currentPage(e) {
    if (e.hasClass('page'))
        return e;
    else
        return currentPage(e.parent());

}

function onElement() {
    if (haszoom) {
        $('*[_moveable="1"]').unbind('touchy-drag').bind('touchy-drag', handleTouchyDrag);
        $('*[_moveable="1"] *').unbind('touchy-drag').bind('touchy-drag', handleTouchyDrag);
        $('canvas[_moveable="1"]').unbind('touchy-pinch').bind('touchy-pinch', handleTouchyPinch);
        $('*[_editable="1"]').unbind('touchend').bind("touchend", handleTouchyEnd);
    } else {
        $('*[_moveable="1"]').unbind('touchy-drag');
        $('*[_moveable="1"] *').unbind('touchy-drag');
        $('img[_moveable="1"]').unbind('touchy-pinch');
        $('*[_editable="1"]').unbind('touchend');
    }
}

function playaudio() {
    if (!jsonOrg.audiosrc || !windowLoad)
        return;
    var audio = document.getElementById("myAudio");
    if (haszoom) {
        if (isClient)
            window.magazine.stopMusic();
        else if (audio.played) {
            audio.pause();
        }
        if ($('.playmusic').length > 0)
            $('.playmusic').remove();
    } else {
        if (isClient)
            window.magazine.playMusic(jsonOrg.audiosrc);
        else if (audio.paused) {
            audio.play();
        }
        if ($('.playmusic').length < 1)
            $('body').append('<div class="playmusic" onclick="stopmusic();"><img class="play" style="width:' + getScaleValue(65) + 'px;height:' + getScaleValue(65) + 'px" src="./image/musicplay.png"/></div>');
    }
}

function stopmusic() {
    var audio = $('audio')[0];
    if ($('.playmusic img').hasClass('play')) {
        if (isClient)
            window.magazine.stopMusic();
        else if (audio.played) {
            audio.pause();
        }
        $('.playmusic img').removeClass('play');
    } else {
        if (isClient)
            window.magazine.playMusic(jsonOrg.audiosrc);
        else if (audio.paused) {
            audio.play();
        }
        $('.playmusic img').addClass('play');
    }
}

function jsonDataToHtml(d, zoom, setTemp, orgzoom, printtype) {
    haszoom = zoom;
    zoomOrg = orgzoom || zoom;
    parm.printtype = arguments[4] ? printtype : 0;
    parm.newAlbums = setTemp ? setTemp : false;
    if (parm.printtype == 1 || parm.printtype == 2) {
        $('#pages').css('font-family', 'FZKATJW');
    }
    if (setTemp == true && parm.printtype == 0)
        albumstemp = d;
    dataInit(d);
    $('audio').attr('src', jsonOrg.audiosrc);
}
function reSetJsonData() {
    var jd = {}, medias;
    jd.width = jsonOrg.width;
    jd.height = jsonOrg.height;
    jd.audiosrc = jsonOrg.audiosrc;
    jd.id = jsonOrg.id;
    jd.title = jsonOrg.title;
    jd.pages = [];
    jd.icon = jsonOrg.icon;
    jd.maxno = parm.newno;
    jsonOrg.header && (jd.header = jsonOrg.header);
    jsonOrg.bid && (jd.bid = jsonOrg.bid);
    jsonOrg.card && (jd.card = jsonOrg.card);
    parm.printtype > 0 && (jd.style = parm.printtype);
    jsonOrg.bbirth && (jd.bbirth = jsonOrg.bbirth);
    jsonOrg.fontlist && (jd.fontlist = jsonOrg.fontlist);
    jsonOrg.pageimglist && (jd.pageimglist = jsonOrg.pageimglist);
    jsonOrg.uInfo && (jd.uInfo = jsonOrg.uInfo);
    $.each(pageparm.pagelist, function (i, c) {
        jd.pages.push(pagedata[c]);
    });
    medias = mediasData;
    jd.medias = medias;
    return JSON.stringify(jd);
}
function getJsonData(isNew) {
    var jd = reSetJsonData();
    if (isClient) {
        if (isNew) {
            var editend = 1;
            $.each(imgedit, function (i, c) {
                if (mediasData[c].source == 1) {
                    editend = 0;
                    return false;
                }
            });
            window.magazine.getJsonData(jd, editend);
        }
        else
            window.magazine.getJsonData(jd);
    }
    else
        return jd;
}

function selectMusic(url) {
    if (url.toLowerCase().indexOf('http://') == -1)
        url = '';
    jsonOrg.audiosrc = url;
    $('audio').attr('src', jsonOrg.audiosrc);
}

function setBtn(show) {
    if (show) {
        if ($('.btnleft').length < 1) {
            var btnW = viewParm.lrbtnW();
            $('body').append('<img class="btnleft" style="display: none;width: ' + btnW + 'px;" src="./image/left.png">');
            $('body').append('<img class="btnright" style="right: 0px;width: ' + btnW + 'px;" src="./image/right.png">');
            var top = viewParm.lrbtnT();
            $(".btnleft").css("top", top);
            $(".btnright").css("top", top);

        }
        var pageaddW, pageaddL;
        $.inArray(parm.printtype, [0, 3]) < 0 || $('#pageadd').length > 0 || ( pageaddW = parm.printtype == 3 ? getScaleValue(jsonOrg.height) : getScaleValue(jsonOrg.width), pageaddL = parm.printtype == 3 ? getScaleValue(jsonOrg.width - jsonOrg.height) / 2 : 0, $('.pagesbox').append('<div class="page" id="pageadd" style="position: relative;text-align: center;width:' + pageaddW + 'px;left:' + pageaddL + 'px;height:100%;background-color: #fff;color: #9a9a9a;"><div style="position: relative;top:28%;"><img class="addnewpge" onclick="initpageimgbox();" style="width:' + getScaleValue(400) + 'px;" src="./image/pageadd.png"></div></div>'));
        if (isClient) {
            if (!$('.editBtn').length > 0) {
                $('.outfloor').append('<div class="editBtn" style="height: ' + viewParm.editBtnH() + 'px;"><div class="pagination" style="top: ' + (viewParm.paginationT() - viewParm.paginationFS()) + 'px;font-size:' + viewParm.paginationFS() + 'px;" ><div class="pagination" style="top: ' + viewParm.paginationT() + 'px;font-size:' + viewParm.paginationFS() + 'px;"></div></div>');
                if (parm.printtype > 0) {
                    $('.editBtn').append('<div class="toprint" style="width: ' + viewParm.toprintW() + 'px;height: ' + viewParm.toprintH() + 'px;line-height: ' + viewParm.toprintH() + 'px;margin-top:' + viewParm.toprintT() + 'px;font-size: ' + viewParm.toprintFS() + 'px;" ontouchend="toPrint();">确认打印</div>');
                } else {
                    $('.editBtn').append('<table cellspacing="0" cellpadding="0" ><tr><td class="music1"><img src="./image/music.png"><p class="music1">音乐</p></td><td class="minpht"><img src="./image/viewed.png"><p>预览</p></td></tr></table>');
                }
                $('.editBtn').find('img').css('width', viewParm.editBtnImgW() + 'px');
                $('.editBtn').find('p').css({
                    'font-size': viewParm.editBtnFS() + 'px',
                    'line-height': viewParm.editBtnFLH() + 'px'
                });
            }
        }
        else {
            if (!$('.editBtn').length > 0) {
                $('.outfloor').append('<div class="editBtn" style="height: ' + viewParm.editBtnH() + 'px;"><div class="pagination" style="top: ' + (viewParm.paginationT() - viewParm.paginationFS()) + 'px;font-size:' + viewParm.paginationFS() + 'px;"></div><table cellspacing="0" cellpadding="0" ><tr><td class="edit"><img src="./image/edit.png"><p>编辑</p></td><td class="minpht"><img src="./image/viewed.png"><p>预览</p></td><td class="release"><img src="./image/release.png"><p>发布</p></td></tr></table></div>');
                $('.editBtn').find('img').css('width', viewParm.editBtnImgW() + 'px');
                $('.editBtn').find('p').css({
                    'font-size': viewParm.editBtnFS() + 'px',
                    'line-height': viewParm.editBtnFLH() + 'px'
                });
            }
            $('.edit').hide();
            $('.minpht').show();
            $('.pagination').show();
        }
        var pagedelW, pagedelR;
        $('.pagedel').length > 0 || (  pagedelW = viewParm.pagedelW(), pagedelR = viewParm.pagedelR(), $('#pages').append('<img class="pagedel" style="position: absolute; z-index:1000; right: -' + pagedelR + 'px;width: ' + pagedelW + 'px;top: -' + pagedelW / 2 + 'px;" src="./image/pagedel.png">'));

        $.each(pageparm.pagelist, function (i, v) {
            $('.d2 ul').append('<li ' + (parm.currentpage == v && 'class="nuw"') + '></li>')
        });

        $(".btnleft").unbind('touchend').bind("touchend", function () {
            changePage('up');
        });
        $(".btnright").unbind('touchend').bind("touchend", function () {
            changePage('down');
        });
        if (isClient && parm.printtype == 0) {
            $('.music1').unbind('touchend').bind("touchend", function () {
                window.magazine.selectMusic(jsonOrg.audiosrc);
            });
        }
        else {
            $('.edit').unbind('touchend').bind("touchend", function () {
                pageZoom(true);
            });
            $('.release > *').unbind('touchend').bind("touchend", function () {
                uploadAlbum();
            });
        }

        $('.minpht').unbind('touchend').bind("touchend", function () {
            guidePreview = true;
            pageZoom(false);
            if (isClient)
                window.magazine.preview(false);
        });
        $('.pagedel').unbind('touchend').bind("touchend", pagedel);
        if ($('.returnEdit').length > 0)
            $('.returnEdit').remove();
        if ($('.gifnextpage').length > 0)
            $('.gifnextpage').remove();
        return;
    }
    if (zoomOrg && isClient && $('.returnEdit').length < 1) {
        $('body').append('<div style="z-index:1000;position: absolute;bottom:3%; text-align: center;width: 100%;"><div class="returnEdit" style="width:' + getScaleValue(120) + 'px;height:' + getScaleValue(120) + 'px; margin: 0px auto;" ><img src="./image/returnEdit.png" style="width: 100%;"></div></div>');
        $('.returnEdit').unbind('touchend').bind("touchend", function () {
            window.magazine.preview(true);
            pageZoom(true);
        });
    }
    if ($('.btnleft').length > 0)
        $('.btnleft').remove();
    if ($('.btnright').length > 0)
        $('.btnright').remove();
    if (isClient) {
        $('.editBtn').length > 0 && $('.editBtn').remove();
    } else if (zoomOrg) {
        if (!$('.editBtn').length > 0) {
            $('.outfloor').append('<div class="editBtn"><div class="pagination" style="top: ' + viewParm.paginationT() + 'px;font-size:' + viewParm.paginationFS() + 'px;"></div><table cellspacing="0" cellpadding="0" ><tr><td class="edit"><img src="./image/edit.png"><p>编辑</p></td><td class="minpht"><img src="./image/viewed.png"><p>预览</p></td><td class="release"><img src="./image/release.png"><p>发布</p></td></tr></table></div>');
            $('.editBtn').find('img').css('width', viewParm.editBtnImgW() + 'px');
            $('.editBtn').find('p').css({
                'font-size': viewParm.editBtnFS() + 'px',
                'line-height': viewParm.editBtnFLH() + 'px'
            });
        }
        $('.edit').show();
        $('.minpht').hide();
        $('.pagination').hide();
        $('.minpht').unbind('touchend').bind("touchend", function () {
            guidePreview = true;
            pageZoom(false);
        });
        $('.edit').unbind('touchend').bind("touchend", function () {
            pageZoom(true);
        });
        $('.release > *').unbind('touchend').bind("touchend", function () {
            get();
        });
    }
    $('.pagedel').length > 0 && $('.pagedel').remove();
    $('#pageadd').length > 0 && $('#pageadd').remove();
    $('.gifnextpage').length > 0 || $('#pages').append('<div class="gifnextpage" style="position: absolute;z-index: 99;right: 0px;top: 47%;"><img src="./image/xiayiye.png" style="height: 35px;"></div>');
    setTimeout("if ($('.gifnextpage').length > 0)$('.gifnextpage').remove();", 5000);
}

function toClientMake() {
    window.client.makeMagazine(JSON.stringify({'title': jsonOrg.title, 'jsdata': albumstemp}));
}
function toClientPrint() {
    window.magazine.albumPrint();
}

function addLastPage(isAdd) {
    if (isClient && parm.isSupportAlbumPrint==1) {
        if (zoomOrg == false && $('.lastpage').length < 1) {
            $('.page').parent().append('<div class="page lastpage" style="position: absolute;"></div>');
            $('.lastpage').css({
                'width': '100%',
                'height': '100%',
                'background-color': '#e4f8df'
            });
            $('.lastpage').append('<div class="uinfo" style="position: absolute;width: 100%;top:' + getScaleValue(236) + 'px;"><div style="  overflow: hidden;position: relative;width: ' + getScaleValue(186) + 'px;height: ' + getScaleValue(186) + 'px;margin: 0px auto;"><img src="' + (jsonOrg.uInfo ? jsonOrg.uInfo.uicon : uicon) + '" style="  width: 100%;height:100%;position: absolute;"/><img src="./image/uicon_floor_1.png" style="  position: absolute;width:100%;height:100%;"/></div><div style="text-align: center;padding-top: ' + getScaleValue(24) + 'px;font-size: ' + getScaleValue(34) + 'px;color:#4a4a4a ">' + (jsonOrg.uInfo ? jsonOrg.uInfo.uname : uname) + '</div><div class="makebtn" onclick="toClientMake();" style=" margin:' + getScaleValue(162) + 'px auto 0px;width: ' + getScaleValue(340) + 'px;  height: ' + getScaleValue(86) + 'px;line-height: ' + getScaleValue(85) + 'px;  font-size: ' + getScaleValue(34) + 'px;  padding: 0px;">点我制作</div><div class="makebtn" onclick="toClientPrint();" style="margin-top:' + getScaleValue(34) + 'px;width: ' + getScaleValue(340) + 'px;  height: ' + getScaleValue(86) + 'px;line-height: ' + getScaleValue(86) + 'px;  font-size: ' + getScaleValue(34) + 'px;  padding: 0px;">打印成书</div></div>')
        }
    }
    else {
        if (isClient || (isClientIn && (parseInt(clientVersion) < 253)))return;
        if (isAdd) {
            if ($('.lastpage').length < 1) {
                $('.page').parent().append('<div class="page lastpage" style="position: absolute;"></div>');
                $('.lastpage').css({
                    'width': '100%',
                    'height': '100%',
                    'background-color': '#e4f8df'
                });
                if (!share)
                    $('.lastpage').append('<div class="uinfo" style="position: absolute;width: 100%;top:' + getScaleValue(150) + 'px;"><div style="  overflow: hidden;position: relative;width: ' + getScaleValue(267) + 'px;height: ' + getScaleValue(318) + 'px;margin: 0px auto;"><img src="' + jsonOrg.icon + '" style="  width: 100%;height:100%;position: absolute;"/><img src="./image/uicon_floor_2.png" style="  position: absolute;width:100%;height:100%;"/></div><div style="text-align: center;padding-top: ' + getScaleValue(30) + 'px;font-size: ' + getScaleValue(34) + 'px;">' + jsonOrg.title + '</div><div class="makebtn" onclick="uploadAlbum();" style="width: ' + getScaleValue(339) + 'px;  height: ' + getScaleValue(85) + 'px;line-height: ' + getScaleValue(85) + 'px;  font-size: ' + getScaleValue(34) + 'px;  padding: 0px;">' + (make ? '发布' : (window.localStorage && (localStorage.thisyearId == GetRequest()['key']) ? '我要分享' : '点我制作')) + '</div>' + (make ? '<p style="text-align: center;font-size:' + getScaleValue(28) + 'px">发布后可以分享作品给好友</p>' : '') + '</div><div class="copyright" style="font-size: ' + getScaleValue(34) + 'px;"><a href="http://share.banketime.com/wapdown">下载宝宝助手</a></div>')
                else
                    $('.lastpage').append('<div class="uinfo" style="position: absolute;width: 100%;top:' + getScaleValue(150) + 'px;"><div style="  overflow: hidden;position: relative;width: ' + getScaleValue(179) + 'px;height: ' + getScaleValue(179) + 'px;margin: 0px auto;"><img src="' + (jsonOrg.uInfo ? jsonOrg.uInfo.uicon : uicon) + '" style="  width: 100%;height:100%;position: absolute;"/><img src="./image/uicon_floor_1.png" style="  position: absolute;width:100%;height:100%;"/></div><div style="text-align: center;padding-top: ' + getScaleValue(30) + 'px;font-size: ' + getScaleValue(50) + 'px;">' + (jsonOrg.uInfo ? jsonOrg.uInfo.uname : uname) + '</div><div style="text-align: center;padding-top: ' + getScaleValue(30) + 'px;font-size: ' + getScaleValue(40) + 'px;">出品</div><div class="makebtn" onclick="uploadAlbum();" style="width: ' + getScaleValue(339) + 'px;  height: ' + getScaleValue(85) + 'px;line-height: ' + getScaleValue(85) + 'px;  font-size: ' + getScaleValue(34) + 'px;  padding: 0px;">点我制作</div></div><div class="copyright" style="font-size: ' + getScaleValue(34) + 'px;"><a href="http://share.banketime.com/wapdown">下载宝宝助手</a></div>')
            }

        } else {
            if ($('.lastpage').length > 0) {
                $('.lastpage').remove();
            }
        }
    }
}
function toPrint() {
        if ($('.toprint').hasClass('canprint')) {
            if(parm.printtype == 3 && count(pageparm.pagelist) < 22)
            {
                alert('页面有点少，需要22页才能够打印哦');
                return;
            }
            if (!parm.tip) {
                alert('为确保打印的效果，请检查上传照片的质量及裁剪是否合适。');
                parm.tip = true;
                return;
            }
            window.magazine.print(JSON.stringify({'jsondata': reSetJsonData()}));
        }
        else {
            if (parm.printtype == 2)
                alert('添加的照片未达到' + count(imgedit) + '张');
            //else if (parm.printtype == 3) {
            //    alert('页面有点少，需要22页才能够打印哦');
            //}
        }
}

function delpage(index) {
    var c = $(".page[id!='pageadd']").length;
    if (index > c)
        return;
    if (parm.printtype == 1 && count(pageparm.pagelist) < 28) {
        alert('不能删除了，页面太少将不支持打印哦！');
        return;
    }
    else if (c == 1) {
        alert('不能删除了，请至少保留一页');
        return;
    }
    var nextpage;
    if ($('.page').index($('.pagenow')) < 0) {
        nextpage = 0;
    } else if ($('.page').eq(index).hasClass('pagenow')) {
        nextpage = index < c - 1 ? index + 1 : index - 1;
    }
    $(".page").eq(nextpage).addClass("pagenow");

    var id = Number($(".page:eq(" + index + ")").attr('id').replace('page', ''));
    var pageIndex = $.inArray(id, pageparm.pagelist);
    var pageDel = 0;
    if (pageIndex > 0 && (pageIndex == (pageparm.pagelist.length - 1) || $('#page' + pageparm.pagelist[pageIndex + 1]).attr('_delable') == 2) && $('#page' + pageparm.pagelist[pageIndex - 1]).attr('_delable') == 2) {
        pageDel = pageparm.pagelist[pageIndex - 1];
    }
    pageparm.pagelist.splice(pageIndex, 1);
    $(".page").eq(index).find('canvas[_editable="1"]').each(function () {
        var no = $(this).attr('id').replace('element', '');
        if ($.inArray(parseInt(no), imgedit) > -1)
            imgedit.splice($.inArray(parseInt(no), imgedit), 1);
        if ($.inArray(no, imghasedit) > -1)
            imghasedit.splice($.inArray(no, imghasedit), 1);
    });
    $(".page").eq(index).remove();
    parm.currentpage = getcurrentpage();
    loadpage();
    if (pageDel) {
        delpage($(".page").index($('#page' + pageDel)));
    }
    changeEditStatus();
    if (parm.printtype != 0)
        window.magazine.delPage();
}

function checkIsEdited() {
    if ($(".pagenobox").length > 0) {
        $(".pagenobox").remove();
    } else {
        window.magazine.isEdited(isEdited);
    }
}

function setText(id, val) {
    $('#' + id).html(val);
    var index = id.replace('element', '');
    elementsData[index]['content'] = val;
    isEdited = true;
    setEditVer(index);
}

function setImg(id, src, source, w, h, ts) {
    var imgno = id.replace('element', '');
    doSetImg(imgno, src, source, w, h, ts);
}

function setTextImg(id, val, src) {
    $('#' + id).css('background-image', 'url(' + src + ')');
    var index = id.replace('element', '');
    elementsData[index].content = val;
    elementsData[index].src = index + '.mid';
    if (!mediasData[index]) mediasData[index] = [];
    mediasData[index]['src'] = src;
    mediasData[index]['type'] = '4';
    setEditVer(index);
}

function doSetImg(imgno, src, source, w, h, ts) {
    var width = getScaleValue(elementsData[pageparm.imgBox[imgno]]['width']);
    var height = getScaleValue(elementsData[pageparm.imgBox[imgno]]['height']);
    var scalew = width / w;
    var scaleh = height / h;
    var scale = scalew > scaleh ? scalew : scaleh;
    var left = scale == scaleh ? (width - w * scale) / 2 : 0;
    var top = scale == scalew ? (height - h * scale) / 2 : 0;
    width = w * scale;
    height = h * scale;
    if ($.inArray(imgno, imghasedit) < 0)
        imghasedit.push(imgno);
    elementsData[imgno]['width'] = pageScale.Divide(width).toString();
    elementsData[imgno]['height'] = pageScale.Divide(height).toString();
    elementsData[imgno]['left'] = pageScale.Divide(left).toString();
    elementsData[imgno]['top'] = pageScale.Divide(top).toString();
    elementsData[imgno]['src'] = imgno + '.mid';
    delete elementsData[imgno]['right'];
    delete elementsData[imgno]['bottom'];
    delete elementsData[imgno]['translate_x'];
    delete elementsData[imgno]['translate_y'];
    delete elementsData[imgno]['scales'];
    delete elementsData[imgno]['degs'];
    if (!mediasData[imgno]) mediasData[imgno] = [];
    mediasData[imgno]['src'] = src;
    mediasData[imgno]['source'] = source;
    mediasData[imgno]['width'] = w;
    mediasData[imgno]['height'] = h;

    var imgElement = $('#element' + imgno);
    if (imgElement.length > 0) {
        var cPage = currentPage(imgElement);
        var pageno = cPage.attr('id').replace('page', '');

        var img = new Image();
        img.src = src;
        img.onload = function () {
            imglist[pageno][imgno] = this;
            drawImg(imgno, pageno);
        }
    }
    if (ts) {
        var pageno = pageparm.imgPage[imgno];
        var timeElement;
        $.each(pagedata[pageno].elements, function (i, c) {
            if (c.type == '1') {
                $.each(c.textelements, function (ii, cc) {
                    if (cc.type == '11' && cc.editDate && cc.editDate == '1') {
                        timeElement = 'element' + cc.no;
                        return false;
                    }
                });
            }
        });
        if (timeElement) {
            setTime(timeElement, ts);
        }
    }
    changeEditStatus();
    isEdited = true;
    setEditVer(imgno);
}

function pageZoom(zoom) {
    if (zoom) {
        if (!parm.zoomScale) {
            var editW = viewParm.left() + viewParm.right();
            var editH = viewParm.top() + viewParm.bottom();
            var height = getScaleValue(jsonOrg.height);
            var width = parm.printtype == 3 ? height : getScaleValue(jsonOrg.width);
            var scalew = (widthOrg - editW) / width;//parm.scalebyh ? ((widthOrg - editW) / widthOrg) : ((widthOrg + (widthOrg - getScaleValue(jsonOrg.width) ) - editW) / widthOrg);
            var scaleh = (heightOrg - editH) / height;//parm.scalebyh ? ((heightOrg + (heightOrg - getScaleValue(jsonOrg.height)) - editH ) / heightOrg) : ((heightOrg - editH) / heightOrg);
            parm.zoomScale = scalew > scaleh ? scaleh : scalew;
        }
        $('#pages').css({
            scale: parm.zoomScale
        }).css('border', '1px solid #dedede').css({translate: ['0px', -viewParm.top() + 'px']});
        $(".page").css({
            'display': '',
            'overflow': 'hidden'
        });
        if (!(count(imghasedit) > 0 || $('.pagenow').attr('id') == 'pageadd')) {
            var firstPage = pageparm.pagelist[0];
            parm.currentpage = firstPage;
            createpage(firstPage);
            loadpage();
        }
    } else {
        $('.editprompt').removeClass('editprompt');
        var firstPage = pageparm.pagelist[0];
        parm.currentpage = firstPage;
        createpage(firstPage);
        loadpage();
        $('#pages').css({
            transform: ''
        }).css({translate: ['0px', '0px']}).css('border', 'auto');
        $(".page").css({
            'overflow': 'inherit'
        });
        // 保证闪烁框消失
        $('.page').find('div[_type="11"][_editable="1"]').css({
            'border-color': 'rgba(165, 189, 47,0)',
            'border-radius': '0px'
        });
    }
    haszoom = zoom;
    setBtn(zoom);
    addLastPage(!zoom);
    setdisplay(zoom);
    reDrawCanvas();
    scrollPage();
    onElement();
    playaudio();
    if (!zoom) {
        timeout = setTimeout('autoUpPage()', 5000);
    }
    else if (timeout) {
        clearTimeout(timeout);
        timeout = 0;
    }
}

var outTime = 0;
var autochange = false, timeout = 0, autoend = false;
function autoUpPage() {
    if (!autoend) {
        var time = (new Date()).valueOf();
        if ((time - outTime >= 5000) && !haszoom && !touchmove && $('.page').length > 1) {
            outTime = time;
            var nowpage = $(".page").index($(".pagenow"));
            var nextpage = nowpage + 1;
            if (nextpage < $(".page").length) {
                autochange = true;
                $(".page").eq(nextpage).transition({translate: [$(".page").width() + 'px', '0px'], duration: 0});
                $(".page").eq(nextpage).addClass('pagenow');
                $(".page").eq(nextpage).transition({
                    translate: ['0px', '0px'],
                    duration: 500,
                    easing: 'cubic-bezier(0,0,0.03,1)',
                    complete: function () {
                        autochange = false;
                        $(".page").eq(nextpage).siblings().removeClass('pagenow');
                        setdisplay(haszoom);
                        loadpage();
                        timeout = setTimeout('autoUpPage()', 5000);
                    }
                });
            }
            else {
                autoend = true;
            }
        }
    }
}

function prepareBatchImg() {
    if ($(".pagenobox").length > 0) {
        $(".pagenobox").remove();
    }
    var maxsize = count(imgedit);
    var size = maxsize - count(imghasedit);
    window.magazine.editBatchImg(size, maxsize);
}

function setBatchImg(JSsrcs) {
    var srcs = JSON.parse(JSsrcs);
    if (imgedit.length == count(imghasedit)) // 重新设置替换图片
        imghasedit = [];
    var BatchImgload = function () {
        var j = 0;
        $.each(imgedit, function (i, c) {
            if ($.inArray(c + '', imghasedit) < 0) {
                var src = srcs[j];
                var ts = src['ts'] || 0;
                setImg('element' + c, src['src'], src['source'], src['w'], src['h'], ts);
                ++j;
                if (j >= srcs.length)
                    return false;
            }
        });
    }
    BatchImgload();
}
function setwebtitle(title) {
    if (isClient && clientVersion > 253) {
        window.location = "window.magazine.setWebTitle" + "?title=" + title;
    }
}
function setdisplay(display) {
    $('.opacity_inited').addClass('opacity_init').removeClass('opacity_inited');
    showAnimate(parm.currentpage, false);
    parm.currentpage = getcurrentpage();
    $('.pagenow').length > 0 || ($('.page').removeClass('pagenow'), $('#page' + parm.currentpage).addClass('pagenow'));
    if (display == false) {
        $('.pagenow').find('.opacity_inited').addClass('opacity_init').removeClass('opacity_inited');
        showAnimate(parm.currentpage, true);
        $(".btnright").css('display', 'none');
        $(".btnleft").css('display', 'none');
        if ($('.returnEdit').length > 0) {
            if ($('.pagenow').hasClass('lastpage'))
                $('.returnEdit').css('display', 'none');
            else
                $('.returnEdit').css('display', 'block');
        }
    } else {
        if (parm.printtype == 3) {
            $('.pagesbox').css("overflow", "visible");
            $('.pagenow').css({"overflow": "visible", "box-shadow": "none", "-webkit-box-shadow": "none"});
        }
        $('.pagenow').find('.opacity_init').addClass('opacity_inited').removeClass('opacity_init');
        showAnimate(parm.currentpage, false);
        var title = '';
        var index = $(".page").index($(".pagenow"));
        if (index == -1) {
            return;
        }
        if ($('#pageadd').hasClass('pagenow')) {
            $(".editBtn").css('display', 'none');
            $(".pagedel").css('display', 'none');
            title = '添加页面';
        } else {
            $(".editBtn").css('display', 'block');
            if ($(".pagenow").attr('_delable') == 2) {
                $(".pagedel").css('display', 'none');
            }
            else {
                $(".pagedel").css('display', 'block');
            }
            if (!isClient) {
                if (make) {
                    $(".music1").css('display', 'none');
                } else {
                    $(".music1").css('display', 'block');
                }
            }
        }
        if (index == 0) {
            $(".btnleft").css('display', 'none');
        } else {
            $(".btnleft").css('display', 'block');
        }
        if (index + 1 == $(".page").length) {
            $(".btnright").css('display', 'none');
        } else {
            $(".btnright").css('display', 'block');
        }
        changeEditStatus();
        setTimeout('setwebtitle("' + title + '")', 100);
    }
}
function changeEditStatus() {
    if (!(parm.printtype == 0)) {
        switch (parm.printtype) {
            case 1:
                if (count(pageparm.pagelist) < 27)
                    $('.toprint').hasClass('canprint') && $('.toprint').removeClass('canprint');
                else
                    $('.toprint').hasClass('canprint') || $('.toprint').addClass('canprint');
                break;
            case 2:
                if (count(imgedit) == count(imghasedit))
                    $('.toprint').hasClass('canprint') || $('.toprint').addClass('canprint');
                else
                    $('.toprint').hasClass('canprint') && $('.toprint').removeClass('canprint');
                break;
            case 3:
                if (count(pageparm.pagelist) < 22) {
                    $('.toprint').hasClass('canprint') || $('.toprint').addClass('canprint');
                    //$('.toprint').hasClass('canprint') && $('.toprint').removeClass('canprint');
                    var pageaddW, pageaddL;
                    $('#pageadd').length > 0 || ( pageaddW = parm.printtype == 3 ? getScaleValue(jsonOrg.height) : getScaleValue(jsonOrg.width), pageaddL = parm.printtype == 3 ? getScaleValue(jsonOrg.width - jsonOrg.height) / 2 : 0, $('.pagesbox').append('<div class="page" id="pageadd" style="position: relative;text-align: center;width:' + pageaddW + 'px;left:' + pageaddL + 'px;height:100%;background-color: #fff;color: #9a9a9a;"><div style="position: relative;top:28%;"><img class="addnewpge" onclick="initpageimgbox();" style="width:' + getScaleValue(400) + 'px;" src="./image/pageadd.png"></div></div>'));

                }
                else {
                    $('.toprint').hasClass('canprint') || $('.toprint').addClass('canprint');
                    $('#pageadd').remove();
                }

                break;
        }
    }
}
function changePage(change) {
    var pcount = $(".page").length;
    var nowpage = $(".page").index($(".pagenow"));
    if (change == 'up') {
        nowpage = nowpage - 1;
    } else if (change == 'down') {
        guideNextPage = true;
        nowpage = nowpage + 1;
    }
    if (nowpage < 0)
        nowpage = 0;
    if (nowpage >= pcount)
        nowpage = pcount - 1;
    $(".page").eq(nowpage).addClass('pagenow').siblings().removeClass('pagenow');
    $(".page").eq(nowpage).transition({translate: ['0px', '0px'], duration: 0});
    setdisplay(true);
    loadpage();
    if (parm.printtype == 3 && $('#pageadd').length > 0 && $.inArray(parm.currentpage, pageparm.pagelist) == count(pageparm.pagelist) - 1)
        changePage(change);
}
function loadpage() {
    if (isNaN(parm.currentpage) || parm.currentpage < 0) return;
    var index = $.inArray(parm.currentpage, pageparm.pagelist);
    $.each(pageparm.pagelist, function (i, c) {
        if (Math.abs(i - index) < 2) {
            createpage(c);
        }
        else {
            ($('#page' + c).length > 0) && ($('#page' + c).remove());
            ($.inArray(c, pageparm.pageloaded) > -1) && (pageparm.pageloaded.splice($.inArray(c, pageparm.pageloaded), 1));
            (imglist[c]) && (delete imglist[c]);
            (pageparm.myCanvas[c]) && (delete pageparm.myCanvas[c]);
        }
    })
}
var touchstart = false, touchmove = false, touchend = true;
var tounchNextPage = false, touchstartx, direction = false, nowpage, nextpage, distance;
var noScroll = false;
function setNoScroll(cs) {
    noScroll = cs;
}
function scrollPage() {
    $("body").swipe({
        swipeStatus: function (event) {
            var page = $(".page");
            switch (event.type) {
                case 'touchstart':
                    if (!(haszoom || autochange || noScroll || $('.page').length < 2||touchydrag)&&touchend) {
                        touchstart = true;
                        touchstartx = event.touches[0].clientX;
                        nowpage = page.index($(".pagenow"));
                    }
                    break;
                case 'touchmove':
                    if (touchstart) {
                        if (timeout) {
                            clearTimeout(timeout);
                            timeout = 0;
                        }
                        distance = event.touches[0].clientX - touchstartx;
                        if (distance == 0) return;
                        touchmove = true;
                        if (!direction) {
                            direction = distance > 0 ? 'down' : 'up';
                            if (direction == 'up') {
                                nextpage = nowpage + 1;
                                if (nextpage >= page.length) return;
                            }
                            else {
                                nextpage = nowpage - 1;
                                if (nextpage < 0) return;
                            }
                            page.eq(nowpage).css('z-index', '0');
                            page.eq(nextpage).addClass('pagenow').css('z-index', '101');
                            tounchNextPage = true;
                        }
                        var pageWidth = page.width();
                        if (direction == 'up') {
                            distance = pageWidth + distance;
                        }
                        else {
                            distance = -pageWidth + distance;
                        }
                        page.eq(nextpage).transition({
                            translate: [distance + 'px', '0px'],
                            easing:'linear',
                            duration: 0
                        });
                    }
                    break;
                default:
                    if (touchmove) {
                        touchstart = false;
                        touchmove = false;
                        touchend = false;
                        if (tounchNextPage) {
                            page.eq(nextpage).transition({
                                translate: ['0px', '0px'],
                                duration: Math.abs(distance) / $(".page").width() * 500,
                                easing: 'cubic-bezier(0,0,0.03,1)',
                                complete: function () {
                                    page.eq(nextpage).transition({
                                        translate: ['0px', '0px'],
                                        duration: 0
                                    });
                                    page.eq(nowpage).removeClass('pagenow');
                                    page.eq(nextpage).css('z-index', '0');
                                    setdisplay(haszoom);
                                    loadpage();
                                    if (nextpage < page.length - 1)
                                        timeout = setTimeout('autoUpPage()', 5000);
                                    else
                                        autoend = true;
                                    tounchNextPage = false;
                                    touchend = true;

                                }
                            });
                        }
                        else {
                            touchend = true;
                        }
                        direction = false;
                    }
                    break;
            }

        }
    });
}
function setTime(id, val) {
    var content = '';
    if (parseInt(jsonOrg.bbirth) > parseInt(val))
        content = '出生前';
    else {
        var YMD = getYMD(parseInt(jsonOrg.bbirth), parseInt(val));
        YMD.D++;
        YMD.Y && (content += YMD.Y + '岁');
        YMD.M && (content += YMD.M + '个月');
        YMD.D && (content += YMD.D + '天');
    }
    content += '(' + (new Date(parseInt(val))).Format('yyyy.MM.dd') + ')';
    $('#' + id) && $('#' + id).html(content);
    var index = id.replace('element', '');

    elementsData[index]['content'] = content;
    elementsData[index]['timeStamp'] = val;
    isEdited = true;
    setEditVer(index);
}
function getYMD(t1, t2) {
    if (t1 > t2) {
        var tmp = t2;
        t2 = t1;
        t1 = tmp;
    }
    var dt1 = new Date(t1);
    var dt2 = new Date(t2);
    var dtY = dt2.getFullYear() - dt1.getFullYear();
    var dtM = dt2.getMonth() - dt1.getMonth();
    var dtD = dt2.getDate() - dt1.getDate();
    if (dtD < 0) {
        dtD = (new Date(dt2.getFullYear(), dt2.getMonth(), 0)).getDate() - dt1.getDate() + dt2.getDate();
        dtM--;
    }
    if (dtM < 0) {
        dtM += 12;
        dtY--;
    }
    return {'Y': dtY, 'M': dtM, 'D': dtD};
}
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1,                 //月份
        "d+": this.getDate(),                    //日
        "h+": this.getHours(),                   //小时
        "m+": this.getMinutes(),                 //分
        "s+": this.getSeconds(),                 //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds()             //毫秒
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

var editMedias = [];
function appendFile() {
    if (!isClient && zoomOrg) {
        $('body').append('<div class="file_div" style="width: 0px;height: 0px;display: none;"><input type="file" name="bkf" id="bkf" accept="image/jpeg" /></div>');
        $('.file_div').on('change', 'input[type="file"]', function () {
            var f = this.files[0];
            if (!f) return;
            var mime_type = f.type;
            if (!mime_type.match('image.jpeg')) {
                alert('请选择正确图片');
                return;
            }
            appendFileLoading();
            var Orientation = null;
            EXIF.getData(f, function () {
                EXIF.getAllTags(this);
                Orientation = EXIF.getTag(this, 'Orientation');
            });
            var reader = new FileReader();
            reader.onload = function (e) {
                var g = new Image();
                g.onload = function () {
                    var a = g.width,
                        b = g.height;

                    //var ac = a > 480 ? 620 / a : 1;
                    //var bc = b > 800 ? 1024 / b : 1;
                    //var c = ac > bc ? bc : ac;
                    //a = a * c;
                    //b = b * c;

                    var k = document.createElement("canvas");
                    k.width = a;
                    k.height = b;
                    var m = k.getContext("2d");
                    var temp;
                    if (Orientation != "" && Orientation != 1) {
                        switch (Orientation) {
                            case 6:
                                m.translate(a / 2, b / 2);
                                temp = a;
                                a = b;
                                b = temp;
                                m.rotate(90 * Math.PI / 180);
                                m.translate(-a / 2, -b / 2);
                                break;
                            case 8:
                                m.translate(a / 2, b / 2);
                                temp = a;
                                a = b;
                                b = temp;
                                m.rotate(-90 * Math.PI / 180);
                                m.translate(-a / 2, -b / 2);
                                break;
                            case 3:
                                m.translate(a / 2, b / 2);
                                m.rotate(180 * Math.PI / 180);
                                m.translate(-a / 2, -b / 2);
                                break;
                        }
                    }
                    m.drawImage(g, 0, 0, a, b);
                    var z = k.toDataURL("image/jpeg", 0.7);
                    var index = editElement.attr('id').replace('element', '');
                    doSetImg(index, z, '3', a, b);
                    editMedias.push(index);
                    $('.fileloading').remove();
                    k = g = reader = null;
                    appendGuideNextPage();// 下一页引导
                    appendGuidePreview();// 预览引导
                    $('.file_div').html($('.file_div').html());
                };
                g.onerror = function () {
                    $('.fileloading').remove();
                    g = reader = null;
                    $('.file_div').html($('.file_div').html());
                    alert("\u7531\u4e8e\u5b89\u5168\u9650\u5236\uff0c\u65e0\u6cd5\u4ece\u624b\u673a\u4e2d\u8bfb\u53d6\u7167\u7247\uff0c\u8bf7\u5c1d\u8bd5\u5728\u6d4f\u89c8\u5668\u4e2d\u6253\u5f00\uff0c\u4f7f\u7528\u62cd\u7167\u4e0a\u4f20\u3002")
                };
                g.src = e.target.result;
            };
            reader.readAsDataURL(f);
        })
    }
}

function appendFileLoading() {
    $('body').append('<div class="fileloading" style="width: 100%;height: 100%;position: absolute;top: 0px;  text-align: center;  padding-top: ' + heightOrg / 2 + 'px;  z-index: 999;background-color: rgba(241,241,241,0.8);font-size: 18px;"><p class="loadText">正在上传图片，请稍后...</p></div>');
}

function uploadAlbum() {
    if (!make) {
        if (!share && window.localStorage && (localStorage.thisyearId == GetRequest()['key']))
            appendShare();
        else {
            if (isClientIn && clientCode) {
                stopmusic();
                try {
                    window.client.makeMagazine(JSON.stringify({'title': jsonOrg.title, 'jsdata': albumstemp}));
                } catch (e) {
                    window.location.href = 'baby://make_magazine?title=' + jsonOrg.title + '&jsdata=' + encodeURIComponent(albumstemp);
                }

            }
            else
                window.location.href = '/view/albums?aid=' + jsonOrg.id;
        }
        return;
    }
    function a() {
        b.uploadIndex++;
        if (b.uploadIndex >= editMedias.length) uploadJSON();
        else {
            imgsrc = mediasData[editMedias[b.uploadIndex]]['src'];
            if (imgsrc.indexOf('http://') >= 0) a();
            else {
                var imgstorage = Storage.get("img_" + $.md5(mediasData[editMedias[b.uploadIndex]]['src']));
                if (typeof(imgstorage) !== 'undefined') {
                    d += mediasData[editMedias[b.uploadIndex]]['src'].length;
                    $('.loadText').html('正在发布作品' + Math.round(d / c * 100) + "%...")
                    mediasData[editMedias[b.uploadIndex]]['src'] = imgstorage;
                    a();
                }
                else {
                    h.open("POST", "/view/photoup", !0);
                    h.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    var cc = "dataStr=" + encodeURIComponent(imgsrc.substr(23));
                    h.send(cc);
                    h.onreadystatechange = function () {
                        if (4 == h.readyState && 200 == h.status) {
                            var data = h.responseText;
                            if (data && data.indexOf('http://') >= 0) {
                                d += mediasData[editMedias[b.uploadIndex]]['src'].length;
                                Storage.set("img_" + $.md5(mediasData[editMedias[b.uploadIndex]]['src']), data);
                                mediasData[editMedias[b.uploadIndex]]['src'] = data;
                                a();
                            } else alert("上传失败，请稍后再试！code:600"), $('.fileloading').remove();
                        } else 4 == h.readyState && (alert("网络忙，请稍后再试！code:" + h.status), $('.fileloading').remove())

                    }
                }
            }
        }
    }

    appendFileLoading();
    $('.loadText').html('正在发布作品');
    var b = this;
    this.uploadIndex = -1;
    for (var c = 0, d = 0, e = 0,len = editMedias.length; e < len; e++) mediasData[editMedias[e]]['src'].indexOf('http://') >= 0 || (c += mediasData[editMedias[e]]['src'].length);
    var h = new XMLHttpRequest;
    h.ontimeout = function (a) {
        alert("上传超时，请在较好的网络环境中再试！"), $('.fileloading').remove();
    };
    h.upload && (h.upload.onprogress = function (a) {
        a.lengthComputable && (a = (d + a.loaded) / c, a = 1 < a ? 1 : a, $('.loadText').html('正在发布作品' + Math.round(100 * a) + "%..."))
    });
    a();
//	Ta.clickStat('发布');
}

function uploadJSON() {
    var a = new XMLHttpRequest;
    upJson = getJsonData();
    a.onreadystatechange = function () {
        if (4 == a.readyState && 200 == a.status) {
            var b = a.responseText;
            b ? (window.localStorage && (localStorage.thisyearId = b), $('.loadText').html('请稍等...'), setTimeout(function () {
                $('.fileloading').remove();
                window.location.href = "/view/albums?key=" + b;
            }, 2E3)) : (alert("上传失败，请稍后再试！code:601"), $('.fileloading').remove())
        } else 4 == a.readyState && (alert("上传失败，请稍后再试！code:" + a.status))
    };
    a.ontimeout = function (a) {
        alert("上传超时，请在较好的网络环境中再试！"), $('.fileloading').remove();
    };
    a.open("POST", "/view/savealbums", !0);
    a.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    a.send("confDataStr=" + encodeURIComponent(upJson));
}

function GetRequest() {
    var url = location.search;
    var theRequest = [];
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        var strs = str.split("&");
        for (var i = 0,len = strs.length; i < len; i++) {
            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}

function appendTextEdit() {
    $(document).attr("title", '编辑文字');
    var elenmentId = editElement.attr('id');
    var textOrg = elementsData[elenmentId.replace('element', '')].content;
    textOrg = textOrg.split('<br>');
    arrDelLastEmpty(textOrg);
    textOrg = textOrg.join('\n');
    $('body').append('<div class="textedit" style="width: 100%;height: 100%;position: fixed;top: 0px;z-index: 999;background-color: #fafafa;font-size: 20px;overflow: hidden;"><textarea style="width:' + (widthOrg - 20) + 'px;font-size: ' + (18 / 414 * widthOrg) + 'px;"></textarea><div class="EditOk">保存</div></div>');
    $('.textedit textarea').focus();
    $('.textedit textarea').val(textOrg);
    $('.EditOk').unbind('touchend').bind("touchend", function () {
        var editText = $('.textedit textarea').val();
        editText = editText.split('\n')
        arrDelLastEmpty(editText);
        editText = editText.join('<br>');
        setText(elenmentId, editText);
        $('.textedit').remove();
        $(document).attr("title", jsonOrg.title);
    });
}
function arrDelLastEmpty(arr) {
    if (arr[arr.length - 1] == '') {
        arr.pop();
        arrDelLastEmpty(arr);
    }
}
var guideNextPage = false;
function appendGuideNextPage() {
    if (!isClient && !guideNextPage && haszoom && parm.printtype == 0) {
        $('body').append('<div class="fileloading" style="width: 100%;height: 100%;position: absolute;top: 0px;  text-align: center;  padding-top: ' + (heightOrg / 2) + 'px;  z-index: 999;background-color: rgba(0,0,0,.8);font-size: 18px;"><img src="./image/GuideNextPage.png" style="width:100%;position: absolute;right: -20px;"/></div>');
        guideNextPage = true;
        $('.fileloading').unbind('touchend').bind("touchend", function () {
            $(this).remove();
        });
    }
}
var guidePreview = false;
function appendGuidePreview() {
    if (!isClient && !guidePreview && haszoom && parm.printtype == 0 && ($(".page").index($(".pagenow")) == $(".page").length - 1)) {
        $('body').append('<div class="fileloading" style="width: 100%;height: 100%;position: absolute;top: 0px;  text-align: center;  z-index: 999;background-color: rgba(0,0,0,.8);font-size: 18px;"><img src="./image/GuidePreview.png" style="width:100%;position: absolute;right: 0px;bottom: 30px;"/></div>');
        guidePreview = true;
        $('.fileloading').unbind('touchend').bind("touchend", function () {
            $(this).remove();
        });
    }
}
function appendShare() {
    $('body').append('<div class="toshare"><img src="./image/toShare01.png"></div>');
    $('.toshare').unbind('touchend').bind("touchend", function () {
        $(this).remove();
    });
}

function getcurrentpage() {
    var id = $(".pagenow").attr('id');
    id = id ? id.replace('page', '') : -1;
    if ($('.pagination').length > 0)
        $('.pagination').html(($.inArray(parseInt(id), pageparm.pagelist) + 1) + '/' + count(pageparm.pagelist));
    return parseInt(id)
}

function initpageimgbox() {
    if (albumstemp) {
        var printtype = parm.printtype;
        var tempAlbums = JSON.parse(albumstemp);
        var imgArr = tempAlbums.pageimglist;
        if (imgArr) {

            if (printtype == 3) {
                $('body').append('<div class="pagenobox pagenoprint"><table style="font-size: ' + (72 * widthOrg / 720) + 'px"><tr><td ><div class="tabs selectedtab tab1">模板页面</div></td><td><div class="tabs tab2">自定义页面</div></td></tr></table><div class="item_content"><ul class="items tab1items items_selected"></ul><ul class="items tab2items"></ul></div></div>');
                $.each(imgArr, function (i, c) {
                    var html = "<li><div class='item'><img class='item_img' _pageno='" + c.no + "' src='" + c.src + "'/>" + (i + 1) + "</div></li>";
                    $(".tab1items").append(html);
                });
                if (parm.customAlbums) {
                    var customAlbums = JSON.parse(parm.customAlbums);
                    $.each(customAlbums.pageimglist, function (i, c) {
                        var html = "<li><div class='item'><img class='item_img' _pageno='" + c.no + "' src='" + c.src + "'/>" + (i + 1) + "</div></li>";
                        $(".tab2items").append(html);
                    });
                }
            }
            else {
                $('body').append('<div class="pagenobox" style="width:' + (widthOrg - 20) + 'px;height:' + (heightOrg - 20) + 'px"><div class="item_content"><ul class="items"></ul></div></div>')
                $.each(imgArr, function (i, c) {
                    var html = "<li><div class='item'><img class='item_img' _pageno='" + c.no + "' src='" + c.src + "'/>" + (i + 1) + "</div></li>";
                    $(".items").append(html);
                });
            }
        }
    }
}
function commScroll() {
    var inter = setInterval(function () {
        var cu = $("#comment_ul");
        var li_h = cu.find("li:last").height();
        n = 0;
        cu.find("li:eq(0)").remove().appendTo("#comment_ul");
        cu.find("li:eq(" + (n - 6) + ")").animate({
            opacity: '0.5',
        }, 1000);
        cu.find("li:eq(" + (n - 5) + ")").animate({
            opacity: '0.7',
        }, 1000);
        cu.find("li:eq(" + (n - 4) + ")").animate({
            opacity: '0.8',
        }, 1000);
        cu.find("li:eq(" + (n - 3) + ")").animate({
            opacity: '1',
        }, 1000);
        cu.find("li:eq(" + (n - 2) + ")").animate({
            opacity: '1',
        }, 1000);
        cu.find("li:eq(" + (n - 1) + ")").animate({
            opacity: '1',
        }, 1000);
    }, 1000);
    return inter;
}
function comment_list(page, brid) {
    $.ajax({
        type: "GET",
        url: templeUrl + 'view/albumcomment',
        dataType: "json",
        data: {page: page, brid: brid},
        async: false,
        timeout: 10000,
        success: function (res) {
            comm_count = res.data.count;
            if (res.data.list) {
                $("#comment_list").append('<ul style="margin-top: 0px;" id="comment_ul"></ul>');
                var list = res.data.list;
                $.each(list, function (n, v) {
                    var html = '';
                    html += '<li class="list_item" to_uid="' + v.uid + '" to_name="' + v.name + '" to_rcid="' + v.rc_id + '">';
                    html += '<img src="' + (v.icon ? v.icon : '/static/image/default_icon_head01.png') + '" />';
                    html += '<span class="content">' + v.content + '</span>';
                    html += '</li>';
                    if (html != '')
                        $("#comment_ul").append(html);
                });
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert('评论列表加载失败，请稍后重试！');
            return;
        }
    });
}
function comment_function() {
    $(document).on("click", "#show_comment", function (e) {
        if ($("#show_comment").attr("src") == './image/click_me.png') {
            setNoScroll(true);
            $("#comment").css("background", "rgba(48,48,48,0.9) none repeat scroll");
            $("#comment").css('height', '100%');
            $("#show_comment").attr("src", "./image/close.png");
        }
        else {
            setNoScroll(false);
            $("#comment").css('background', "");
            $("#comment").css('height', 'auto');
            $("#show_comment").attr("src", "./image/click_me.png");
        }
        $("#comment_list").toggle();
        $("#add").toggle();
        $("#comment").scrollTop($("#comment")[0].scrollHeight);
    });

    $(document).on("touchstart", ".list_item", function (e) {
        var comm = '回复 @' + $(this).attr('to_name') + ':';
        defaultCont = comm;
        $(".comm_cont").focus();
        $(".comm_cont").val(comm);
        to_uid = $(this).attr('to_uid');
        to_rcid = $(this).attr('to_rcid');
    });

    $(document).on("touchstart", ".list_item", function (e) {
        clearInterval(inter);
    });

    $(document).on("touchend", ".list_item", function (e) {
        if (comm_count > 5)
            inter = commScroll();
    });

    $(".comm_cont").blur(function () {
        if ($(this).val() == '') {
            $(this).val(defaultCont);
            $(this).attr('color', '#CCCCCC');
        }
    });

    $(".comm_cont").focus(function () {
        $(this).val('');
        $(this).attr('color', '#333333');
    });

    $(".comm_cont").bind('input propertychange', function () {
        var str = $(this).val();
        var index = str.indexOf(":");
        if (str.indexOf("@") != -1 && index != -1) {
            index++;
            $(".comm_cont").val(str.substr(index));
        }
    });

    $(".add_comment").click(function () {
        var content = $(".comm_cont").val();
        if (content == '' || content == defaultCont)
            alert("请填写评论");
        else {
            $.ajax({
                type: "POST",
                url: templeUrl + 'view/addalbumcomment',
                dataType: "json",
                data: {brid: bbrecord_id, uid: user_id, touid: to_uid, content: content, torcid: to_rcid},
                timeout: 3000,
                success: function (data) {
                    alert('评论成功！');
                    $(".comm_cont").val('');
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    alert('评论失败，请重试！');
                    return;
                }
            });
            to_uid = 0;
            to_rcid = 0;
            defaultCont = '说点什么，关爱一下吧';
        }
    });
}